from django.shortcuts import render
from django.http import JsonResponse
from lxml import html
import requests
import pandas as pd
# Create your views here.
def sector_wise_volumes(request):
    url = "https://www.dsebd.org/latest_share_price_scroll_by_ltp.php"
    df = pd.read_html(url)
    df = df[384]
    totalVolume = 0
    for i in range(384):
        totalVolume = totalVolume + df.iat[i, 10]

    sectorFile = open("companysector.txt", "r")
    sectorFlag = 1
    currentSector = ""
    companySectorDictionary = {}
    for line in sectorFile:
        if line == "\n":
            sectorFlag = 1
        else:
            line = line.strip()
            if sectorFlag == 1:
                currentSector = line
                sectorFlag = 0
            else:
                companySectorDictionary[line] = currentSector

    sectorVolumeCount = {}
    for i in range(384):
        if df.at[i, 'TRADING CODE'] in companySectorDictionary:
            sectorOfCompany = companySectorDictionary[df.at[i, 'TRADING CODE']]
        if sectorOfCompany in sectorVolumeCount:
            sectorVolumeCount[sectorOfCompany] = sectorVolumeCount[sectorOfCompany] + df.at[i, 'VOLUME']
        else:
            sectorVolumeCount[sectorOfCompany] = 1

    sectorVolumePercentage = {}
    for sectorOfCompany in sectorVolumeCount:
        sectorVolumePercentage[sectorOfCompany] = (sectorVolumeCount[sectorOfCompany] * 100) / totalVolume


    return JsonResponse({'data': sectorVolumePercentage})